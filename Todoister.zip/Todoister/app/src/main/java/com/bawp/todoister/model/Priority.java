package com.bawp.todoister.model;

public enum Priority {
    HIGH,
    MEDIUM,
    LOW
}

